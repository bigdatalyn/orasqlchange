# Changelog

## 1.1.0 - 2026-07-22

### Added

- Localized conversion diagnostics now remain language-correct across cache hits and language changes in the Web UI.
- Non-SQL and comment-only input detection with localized guidance shown below the target SQL title while retaining the original input in the editor.
- Oracle PL/SQL and SQL*Plus delimiter recognition so anonymous blocks and package bodies are not misclassified as non-SQL content.

### Changed

- Release version advanced to 1.1.0.

## Unreleased

### Added

- `python -m api.main -h` (`-help` / `--help`) prints the API invocation methods and endpoint catalogue without starting the server: startup commands, key environment variables, the `X-Session-ID` authentication model, the full endpoint list grouped by category with required permissions, common request bodies, and curl examples.

## 1.0.0 - 2026-07-17

### Added

- Version-aware Oracle 12c, 19c, and 26ai conversion profiles.
- Extensible conversion pipeline and rule registry for MySQL, SQL Server, PostgreSQL, and Db2.
- Localized Web UI, batch conversion, report downloads, Oracle validation, and disposable-schema execution.
- SQLite persistence for rule feedback with review workflow.
- Fixed server-side report author and organization metadata.
- Wheel, sdist, release ZIP, and installation smoke tests.

### Security

- Removed implicit weak default accounts.
- Added protected bootstrap administrator configuration and explicit demo-user opt-in.
- Defaulted service binding to loopback and enforced a single worker.
- Packaged UI dependencies locally instead of loading runtime CDN scripts.
- Added storage error sanitization, password-file permission checks, and release integrity checks.

### Changed

- Application version promoted from 0.3.0 to 1.0.0.
- Python requirement corrected to 3.10 or newer.
- `datetime.utcnow()` and Passlib crypt deprecations replaced with compatible implementations.
