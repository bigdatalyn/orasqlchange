# Security

## Supported Release

Security fixes target Ora SQL Change 1.0.x. Report suspected issues privately to the internal application owner; do not include passwords, connection strings, production SQL, or row data in reports.

## Deployment Boundary

- Run one application process with one Uvicorn worker.
- Bind to loopback by default and use a managed TLS reverse proxy for network access.
- Keep `OSC_CORS_ORIGINS` limited to exact trusted origins.
- Do not enable `OSC_ENABLE_DEMO_USERS` outside isolated demonstrations.
- Prefer `OSC_BOOTSTRAP_ADMIN_PASSWORD_FILE` with mode `0600`.
- Restrict the SQLite database and backup files to the service account.

## Data Handling

The converter may process proprietary SQL. Rule feedback can persist SQL examples. Reports can contain source and converted SQL. Protect these artifacts according to the source system's data classification. Oracle validation credentials are request-scoped and must never be added to logs or reports.

## AI Suggestion Data Handling

AI SQL conversion suggestions are manually triggered and advisory only. They never alter, execute, cache, persist, or certify converted SQL.

- SQL, converted SQL, and diagnostic messages are sanitized by default before they leave the application.
- Sending original SQL requires the user to type `SEND_ORIGINAL_SQL` for every request. The confirmation does not persist.
- API keys are normally read from environment variables named by a protected mode-`0600` config file. Administrators may supply a temporary replacement in Settings; it remains process-memory-only, is never returned or logged, and disappears after restart.
- Provider Settings requires `system:config`. Non-secret values are atomically written to the protected file. OpenAI/Claude URLs remain fixed; editable local URLs are restricted to localhost/loopback.
- External provider URLs are fixed to official HTTPS endpoints. Local OpenAI-compatible providers are restricted to loopback URLs.
- Logs and audit records contain only request metadata; they exclude SQL, diagnostics, prompt bodies, API keys, and raw model output.
- The browser stores generated suggestions only in JavaScript memory. Refreshing or closing the page removes them.
- AI candidate SQL is model-generated and untrusted. It is never applied, executed, validated, or certified automatically.
- Exported AI Markdown intentionally contains source SQL, deterministic converted SQL, and AI candidate SQL. Treat it as a sensitive migration artifact; it still excludes API keys and sanitization mappings.
- Treat model output as untrusted. The UI escapes output and never executes model-generated code or URLs.

When proprietary SQL must not leave the environment, disable external providers or set `AI_SUGGESTIONS_DISABLED=1` and use only a controlled loopback provider.

## Known Boundaries

Users, sessions, reports, batch jobs, AI suggestion quotas, and execution-log metadata are process-local. A restart invalidates sessions and removes non-persistent runtime state. SQLite feedback is intended for a single application instance. Version 1.1.0 does not support clustered or multi-worker deployment.

Checksums detect accidental or malicious modification only when `SHA256SUMS` is obtained through an independent trusted channel. Version 1.1.0 release artifacts are not digitally signed.
