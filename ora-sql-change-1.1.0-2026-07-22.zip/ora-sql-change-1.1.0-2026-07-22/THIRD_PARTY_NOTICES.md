# Third-Party Notices

Ora SQL Change packages the following browser assets for offline operation:

- Tailwind CSS 3.4.17 runtime distribution — MIT License. See `src/ui/vendor/licenses/TAILWIND-LICENSE.txt`.
- Font Awesome Free 6.4.0 — icons, fonts, and CSS under the Font Awesome Free license terms. See `src/ui/vendor/licenses/FONTAWESOME-LICENSE.txt`.

Python dependency licenses remain governed by their respective installed distributions. Review the release dependency inventory before redistribution.
