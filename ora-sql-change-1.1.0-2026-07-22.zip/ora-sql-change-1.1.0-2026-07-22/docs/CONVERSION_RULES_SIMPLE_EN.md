# Essential SQL Conversion Rules for Oracle

Version: 1.1.0  
Sources: MySQL, SQL Server, PostgreSQL, Db2  
Targets: Oracle 12c, Oracle 19c, Oracle AI Database 26ai

For the complete rule catalog, see [CONVERSION_RULES.md](CONVERSION_RULES.md).

## 1. Oracle Target Profiles

| Feature | Oracle 12c | Oracle 19c | Oracle 26ai |
|---|---|---|---|
| SQL Boolean | `NUMBER(1)` with `CHECK` | `NUMBER(1)` with `CHECK` | `BOOLEAN` |
| JSON storage | `VARCHAR2` or `CLOB` with `IS JSON` | `CLOB` or `BLOB` with `IS JSON` | Native `JSON` |
| Identifier length | 12.1: 30 bytes; 12.2: 128 bytes | 128 bytes | 128 bytes |
| Private temporary tables | Not available | Supported | Supported |
| Conversion-error defaults | 12.1 requires PL/SQL; 12.2 supports SQL syntax | Supported | Supported |

## 2. MySQL to Oracle

| MySQL | Oracle conversion |
|---|---|
| `TINYINT`, `SMALLINT`, `INT`, `BIGINT` | `NUMBER(3)`, `NUMBER(5)`, `NUMBER(10)`, `NUMBER(19)` |
| `DECIMAL(p,s)` | `NUMBER(p,s)` |
| `VARCHAR(n)` | `VARCHAR2(n CHAR)` |
| `TEXT` and large text types | `CLOB` |
| `BLOB` and binary types | `BLOB` or `RAW(n)` |
| `DATETIME` | `TIMESTAMP` |
| `JSON` | Version-specific Oracle JSON storage |
| `AUTO_INCREMENT` | Identity column, or sequence and trigger |
| `ENGINE`, `CHARSET`, `COLLATE` table options | Remove or map to Oracle storage and collation settings |
| `LIMIT n OFFSET m` | `OFFSET m ROWS FETCH NEXT n ROWS ONLY` |
| `IFNULL`, `IF` | `NVL`/`COALESCE`, `CASE` |
| `GROUP_CONCAT` | `LISTAGG` |
| Backtick identifiers | Oracle identifiers; quote only when required |

## 3. SQL Server to Oracle

| SQL Server | Oracle conversion |
|---|---|
| `BIT` | `NUMBER(1)` with `CHECK`; native `BOOLEAN` on 26ai |
| `INT`, `BIGINT` | `NUMBER(10)`, `NUMBER(19)` |
| `MONEY`, `DECIMAL(p,s)` | `NUMBER(p,s)` |
| `VARCHAR(MAX)`, `TEXT` | `CLOB` |
| `NVARCHAR(MAX)`, `NTEXT` | `NCLOB` |
| `DATETIME`, `DATETIME2` | `TIMESTAMP` |
| `DATETIMEOFFSET` | `TIMESTAMP WITH TIME ZONE` |
| `UNIQUEIDENTIFIER` | `RAW(16)` or `VARCHAR2(36 CHAR)` |
| `IDENTITY(seed, increment)` | Identity column, or sequence and trigger |
| `TOP n` and `OFFSET ... FETCH` | Oracle `FETCH FIRST` or `OFFSET ... FETCH` |
| `ISNULL`, `GETDATE`, `DATEADD` | `NVL`, `SYSDATE`/`SYSTIMESTAMP`, interval or date arithmetic |
| `WITH (NOLOCK)` and locking hints | Remove and review Oracle transaction semantics |
| `GO`, brackets, `@variables` | Remove batch separator; convert identifiers and PL/SQL variables |

## 4. PostgreSQL to Oracle

| PostgreSQL | Oracle conversion |
|---|---|
| `SMALLINT`, `INTEGER`, `BIGINT` | `NUMBER(5)`, `NUMBER(10)`, `NUMBER(19)` |
| `NUMERIC(p,s)` | `NUMBER(p,s)` |
| `TEXT` | `CLOB` |
| `BYTEA` | `BLOB` |
| `BOOLEAN` | `NUMBER(1)` with `CHECK`; native `BOOLEAN` on 26ai |
| `TIMESTAMP WITH TIME ZONE` | `TIMESTAMP WITH TIME ZONE` |
| `JSON`, `JSONB` | Version-specific Oracle JSON storage |
| `UUID` | `RAW(16)` or `VARCHAR2(36 CHAR)` |
| `SERIAL`, `BIGSERIAL`, identity | Oracle identity column or sequence |
| `LIMIT` and `OFFSET` | Oracle `FETCH FIRST` or `OFFSET ... FETCH` |
| `ILIKE` | `LOWER(left) LIKE LOWER(right)` or an Oracle collation strategy |
| `STRING_AGG`, `COALESCE`, `NOW()` | `LISTAGG`, `COALESCE`, `CURRENT_TIMESTAMP` |
| `RETURNING`, `ON CONFLICT` | Oracle `RETURNING INTO`; `MERGE` or PL/SQL logic |

## 5. Db2 to Oracle

| Db2 | Oracle conversion |
|---|---|
| `SMALLINT`, `INTEGER`, `BIGINT` | `NUMBER(5)`, `NUMBER(10)`, `NUMBER(19)` |
| `DECIMAL(p,s)` | `NUMBER(p,s)` |
| `DECFLOAT` | `NUMBER` or `BINARY_DOUBLE` after precision review |
| `VARCHAR`, `CLOB`, `BLOB` | `VARCHAR2`, `CLOB`, `BLOB` |
| `GRAPHIC`, `VARGRAPHIC`, `DBCLOB` | `NCHAR`, `NVARCHAR2`, `NCLOB` |
| `TIMESTAMP` | Oracle `TIMESTAMP` |
| `XML` | `XMLTYPE` |
| `GENERATED ... AS IDENTITY` | Oracle identity column |
| `FETCH FIRST n ROWS ONLY` | Keep Oracle-compatible row limiting syntax |
| `WITH UR`, `WITH CS`, `WITH RS`, `WITH RR` | Remove and review Oracle isolation behavior |
| `CURRENT DATE`, `CURRENT TIMESTAMP` | `CURRENT_DATE`, `CURRENT_TIMESTAMP` |
| `VALUE`, `VARCHAR_FORMAT`, `DAYS` | `COALESCE`, `TO_CHAR`, Oracle date arithmetic |
| `FINAL TABLE`, temporal tables | Rewrite with `RETURNING`, PL/SQL, or application logic |

## 6. Stored Programs and Common Rules

| Source feature | Oracle conversion |
|---|---|
| Procedures and functions | Convert to PL/SQL parameter, declaration, exception, and return syntax |
| Triggers | Use `:NEW` and `:OLD`; review row-level and statement-level behavior |
| Dynamic SQL | Use `EXECUTE IMMEDIATE` with bind variables |
| Error handling | Convert source handlers or `TRY/CATCH` blocks to PL/SQL `EXCEPTION` blocks |
| Empty strings | Oracle treats `''` as `NULL`; review comparisons and constraints |
| Identifier case | Unquoted Oracle identifiers are uppercase |
| Reserved words | Rename identifiers or apply Oracle quoting consistently |
| Date and time zones | Validate session time zone, precision, and daylight-saving behavior |
| Transaction control | Review commits, savepoints, isolation, locking, and autonomous transactions |
| Unsupported features | Preserve a diagnostic and require manual review |

## 7. Validation Priorities

1. Compile every converted DDL and PL/SQL object on the selected Oracle version.
2. Compare query results, null behavior, date calculations, and numeric precision.
3. Test indexes, constraints, identity generation, triggers, and generated columns.
4. Verify JSON, XML, LOB, character-set, and time-zone behavior.
5. Review performance plans and transaction behavior before production use.
