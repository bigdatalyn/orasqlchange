# Deployment Guide

## Supported Topology

Ora SQL Change 1.1.0 supports one application instance and one Uvicorn worker. Put a TLS reverse proxy in front of the loopback-bound service for network access. Multi-worker or multi-node deployment is unsupported because users and sessions are stored in process memory.

## Install and Start

Install the Wheel in a dedicated Python 3.10+ virtual environment. Configure a bootstrap administrator using a mode `0600` password file, then start:

```bash
python -m uvicorn api.main:app --host 127.0.0.1 --port 8000 --workers 1
```

For the extracted release ZIP, install its bundled Wheel and then run `./start.sh`. The script supports both Wheel and installed source layouts, provides the same safe single-worker defaults, and refuses to terminate another process if the configured port is occupied.

To inspect the API calling methods and endpoint catalogue without starting the server, run `python -m api.main -h` (`-help` and `--help` are equivalent). The output lists startup commands, key environment variables, the `X-Session-ID` authentication model, every endpoint grouped by category with its required permission, common request bodies, and curl examples.

The installed CLI can also call the API directly through the `ora-sql-change api` command group. It persists the server URL and authenticated session in `~/.ora-sql-change/config.json` so that automation scripts do not need to re-enter credentials. Typical flow: `api configure`, `api login`, then `api convert` / `api batch` / `api suggest`. See `docs/osc_app_readme.md` for the full command reference.

## Required Security Controls

- Terminate TLS at a controlled reverse proxy.
- Limit request body size and trusted source networks at the proxy.
- Set exact trusted origins through `OSC_CORS_ORIGINS` only when cross-origin access is required.
- Keep demo users disabled.
- Protect Oracle credentials outside shell history and application logs.
- Use only non-production Oracle systems for disposable-schema execution.

## SQLite Feedback Data

Set `OSC_DATABASE_PATH` to a durable service-owned path. Source deployments otherwise use `data/ora_sql_change.db`; installed Wheels use `~/.ora_sql_change/data/ora_sql_change.db`.

Before upgrade, stop the application and copy the database together with any `-wal` and `-shm` files. Alternatively use the SQLite online backup API. Verify backup readability before replacing the application.

Rollback procedure:

1. Stop the application.
2. Preserve the failed deployment database and logs for diagnosis.
3. Restore the matching pre-upgrade SQLite backup.
4. Reinstall the previous Wheel in a clean virtual environment.
5. Start one worker and verify login, conversion, feedback, and report download.

## AI Suggestions Configuration

AI suggestions are disabled unless a configured provider is available. Copy `config/ai_providers.env.example` to a service-owned location, set mode `0600`, and point `OSC_AI_CONFIG_FILE` to it. API keys are never stored in that file; configure the environment variables named by each `*_API_KEY_ENV` entry.

- OpenAI and Claude calls use fixed official HTTPS endpoints.
- Local OpenAI-compatible endpoints must use `localhost` or a loopback IP address.
- The browser cannot submit provider URLs, model names, keys, or inference parameters.
- SQL and diagnostics are sanitized by default; every original-SQL request requires `SEND_ORIGINAL_SQL` confirmation.
- Provider failures affect only the AI panel. Deterministic conversion and existing reports remain available.
- Rate and concurrency state is process-local, matching the supported one-worker topology.
- Set `AI_SUGGESTIONS_DISABLED=1` for a fail-closed operational disable switch.

Administrators with `system:config` can edit non-secret provider settings in the Web Settings page. Saves are atomic and immediately replace the active in-process orchestrator. OpenAI/Claude endpoints remain fixed; only local loopback URLs are editable. Temporary API keys entered in Settings live only in process memory and disappear after restart; environment-variable keys remain the durable secret source.

The configured file path must be writable by the service account for Settings saves. Back up the protected config before operational changes; rollback by restoring the matching mode-`0600` file and restarting. Do not put AI configuration secrets in backups, release ZIPs, logs, support bundles, or the config file itself.

## Batch History Deletion

Batch history can contain source SQL, converted SQL, and diagnostics. Owners can permanently delete their completed history; administrators can delete any visible completed history. Bulk deletion is all-or-nothing and active jobs cannot be deleted. SQLite foreign-key cascade removes all file-level results with the job. Backups may still retain deleted SQL according to the backup retention policy.

## Operational Checks

- `GET /` returns the Web UI.
- `GET /api/rules/mysql` returns a rule catalog and reference link.
- `GET /reference/conversion-rules?lang=zh` returns the multilingual HTML rule guide.
- Login succeeds only for explicitly configured users.
- Feedback survives a controlled service restart.
- Logs contain no passwords, connection strings, SQL bodies, report bodies, AI API keys, AI prompt bodies, or raw model responses.
- `GET /api/ai-suggestions/providers` returns only configured Provider metadata to users with `ai:basic`.
- AI suggestions and their 1–2 candidate Oracle SQL statements are generated only after an explicit user action and disappear after page refresh.
- Timestamped AI Markdown exports intentionally include source SQL, deterministic converted SQL, and AI candidate SQL; secure them as sensitive migration artifacts.
- The filesystem containing SQLite and reports has monitored free space and backups.
