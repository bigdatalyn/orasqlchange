# Release Checklist

## Source

- [ ] Version is `1.1.0` in the single version module, API, CLI, Wheel, and sdist.
- [ ] Conversion rules and packaged rule reference are byte-identical.
- [ ] No weak default users, credentials, databases, logs, caches, or `.DS_Store` files remain.
- [ ] README, architecture, deployment, security, target profiles, and test documentation are current.
- [ ] `config/ai_providers.env.example` contains no secrets; real `config/ai_providers.env` is excluded.
- [ ] AI Settings requires `system:config`, loads protected-file defaults, atomically persists non-secret values, reloads immediately, rejects non-loopback local URLs, and never returns/logs temporary keys.
- [ ] Restart preserves file-backed settings but clears temporary in-memory API keys.

## Validation

- [ ] `pytest -W error::DeprecationWarning` passes.
- [ ] External database skips are recorded and separately approved.
- [ ] Wheel and sdist include UI HTML, local static assets, licenses, and packaged rule reference.
- [ ] Wheel installation succeeds in a clean temporary virtual environment.
- [ ] CLI version, Web root, conversion API, bootstrap login, SQLite restart, and reports pass smoke tests.
- [ ] The Web UI renders without network access.
- [ ] AI provider discovery requires `ai:basic`; conversion never auto-calls AI when legacy `enable_ai=true` is supplied.
- [ ] Batch history single/bulk deletion enforces owner/admin access, rejects active jobs, cascades file results, and presents explicit permanent-delete confirmation.
- [ ] AI configuration, sanitizer, schemas, mocked providers, limits, partial responses, and error mapping tests pass.
- [ ] Manual AI smoke test covers single and batch-file suggestions, 1–2 candidate SQL statements, raw-SQL confirmation, retry, timestamped export, refresh, and service restart.
- [ ] AI Markdown export contains exact source SQL, exact deterministic converted SQL, all candidate SQL, safe code fences, and the sensitive-artifact warning.
- [ ] All download filenames use the `OraSqlChange_<Type>_YYYYMMDD_HHMMSS[_<Identifier>].<ext>` convention.
- [ ] Logs, SQLite, reports, batch results, caches, and built artifacts contain no AI keys, prompt bodies, or model raw responses.

## Artifacts

- [ ] Build Wheel and sdist with PEP 517 isolation.
- [ ] Create the release ZIP from an explicit whitelist.
- [ ] Verify ZIP excludes tests, runtime databases, WAL/SHM files, caches, logs, and development specifications.
- [ ] Generate SHA-256 for Wheel, sdist, and ZIP.
- [ ] Distribute `SHA256SUMS` through an independent trusted channel.

## Deployment

- [ ] Back up SQLite consistently and test restore.
- [ ] Use one worker, loopback binding, TLS reverse proxy, and exact CORS origins.
- [ ] Bootstrap password file is mode `0600`; demo users are disabled.
- [ ] Rollback Wheel and matching database backup are available.
