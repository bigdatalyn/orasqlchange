# Ora SQL Change - 异构数据库 SQL 迁移工具

> 版本：1.1.0 | 更新日期：2026-07-22

## 项目概述

**Ora SQL Change** 是一款异构数据库 SQL 迁移工具，支持将 **MySQL、SQL Server、PostgreSQL、Db2** 的 SQL 语句转换为 **Oracle** 方言。提供 REST API、Web UI、CLI 命令行及 VS Code 扩展四种使用方式，覆盖从单条 SQL 转换到批量迁移的完整场景。

---

## 技术栈

| 层级 | 技术选型 |
|------|----------|
| 后端框架 | Python 3.10+、FastAPI、Click |
| 前端界面 | HTML、Tailwind CSS 3.4.17、Font Awesome 6.4.0 |
| 持久化 | SQLite |
| 数据库驱动 | oracledb、psycopg、pymysql、pyodbc、ibm_db |
| AI 集成 | OpenAI、Claude、本地 LLM（仅使用 stdlib urllib） |
| 安全认证 | bcrypt、python-jose、RBAC 五级角色 |
| 打包分发 | setuptools、wheel |

---

## 核心功能

### 1. SQL 转换引擎

转换引擎采用 **Pipeline 流水线架构**，核心流程如下：

1. **语句分类**：识别 SQL 类型（DDL / SELECT / INSERT / UPDATE / DELETE / MERGE / CTE / TRIGGER / PROCEDURE / PARTITION）
2. **Token 保护**：通过 TokenVault 机制保护字面量、注释、标识符，防止规则误改用户数据
3. **分阶段规则执行**：BOUNDARY → SOURCE_DDL/QUERY → TARGET_PROFILE → COMMON_OBJECT → FINALIZE
4. **类型分支处理**：根据语句类型分发到对应处理分支（过程化 SQL、分区、DDL、查询）

#### 支持的源端数据库及转换规则

| 源端 | 关键转换规则 |
|------|-------------|
| **MySQL** | AUTO_INCREMENT → IDENTITY、IFNULL → COALESCE、GROUP_CONCAT → LISTAGG、类型映射 |
| **SQL Server** | BIT → NUMBER(1)/BOOLEAN、UNIQUEIDENTIFIER → RAW(16)、NOLOCK 提示移除、索引转换 |
| **PostgreSQL** | SERIAL → IDENTITY、BYTEA → BLOB、ILIKE → UPPER() LIKE、JSON/JSONB 处理 |
| **Db2** | Schema 限定符移除、ALIAS → SYNONYM、VALUE() → NVL()、时态表处理 |
| **通用规则** | 事务控制、分页（LIMIT → FETCH FIRST）、空字符串处理、IF NOT EXISTS 移除、标识符长度检查、序列处理 |

#### Oracle 目标版本配置

| 目标版本 | BOOLEAN 处理 | JSON 处理 | 标识符长度 |
|----------|-------------|-----------|-----------|
| `oracle_12c` | NUMBER(1) + CHECK 约束 | VARCHAR2/CLOB + IS JSON | 30 字节（12.1） |
| `oracle_19c` | NUMBER(1) + CHECK 约束 | VARCHAR2/CLOB + IS JSON | 128 字节 |
| `oracle_26ai` | 原生 BOOLEAN | 原生 JSON 类型 | 128 字节 |

### 2. REST API

核心端点：

| 端点 | 功能 | 需要认证 |
|------|------|----------|
| `POST /api/convert` | 单条 SQL 转换 | 否 |
| `POST /api/convert/enhanced` | 兼容性转换端点 | 否 |
| `POST /api/convert/view` | 视图转换 | 否 |
| `POST /api/convert/cte` | CTE 转换 | 否 |
| `POST /api/convert/window` | 窗口函数转换 | 否 |
| `POST /api/convert/functions` | 函数转换 | 否 |
| `POST /api/convert/procedure` | 存储过程转换 | 否 |
| `POST /api/convert/trigger` | 触发器转换 | 否 |
| `POST /api/convert/partition` | 分区转换 | 否 |
| `POST /api/analyze` | SQL 分析 | 否 |
| `POST /api/migration-plan` | Db2 迁移计划（仅 db2） | 否 |
| `POST /api/ai-suggestions` | AI 智能建议 | 是（`ai:basic`） |
| `POST /api/oracle26ai/validate` | EXPLAIN PLAN 只读验证 | 是（`convert:advanced`） |
| `POST /api/oracle26ai/execute-disposable-schema` | 一次性 Schema 执行验证 | 是（`system:config`） |
| `POST /api/auth/login` | 用户登录 | 否 |
| `POST /api/auth/logout` | 用户注销 | 是 |
| `GET  /api/auth/me` | 当前用户信息 | 是 |
| `POST /api/reports/generate` | 报告生成 | 是（`reports:view`） |
| `GET  /api/reports/{id}/download/{format}` | 下载报告（html/markdown） | 是 |

批量转换端点（前缀 `/api/batch`）：

| 端点 | 功能 | 需要认证 |
|------|------|----------|
| `POST   /api/batch/submit` | 提交批量任务 | 是（`convert:batch`） |
| `GET    /api/batch/jobs` | 任务列表 | 是（`convert:batch`） |
| `GET    /api/batch/status/{job_id}` | 任务状态 | 是 |
| `GET    /api/batch/results/{job_id}` | 任务结果 | 是 |
| `GET    /api/batch/results/{job_id}/download/{format}` | 下载任务结果（zip/markdown） | 是 |
| `DELETE /api/batch/jobs/{job_id}` | 删除任务 | 是（`convert:batch`） |
| `POST   /api/batch/jobs/delete` | 批量删除 | 是（`convert:batch`） |
| `DELETE /api/batch/cancel/{job_id}` | 取消任务 | 是 |

其他端点：

| 端点 | 功能 | 需要认证 |
|------|------|----------|
| `GET  /health` | 健康检查 | 否 |
| `GET  /api/rules/{db_type}` | 源库转换规则 | 否 |
| `GET  /api/languages` | 支持的语言列表 | 否 |
| `GET  /api/ai-suggestions/providers` | 可用 AI 提供商 | 是（`ai:basic`） |
| `POST /api/rule-feedback` | 提交规则反馈 | 是（`convert:basic`） |

完整接口说明可通过 `python -m api.main -h` 查看。

### 3. CLI 命令行

CLI 基于 Click 框架构建，提供 4 个子命令，覆盖单文件转换、批量转换、规则查询和 SQL 分析场景。

**安装：**

```bash
pip install dist/ora_sql_change-1.1.0-py3-none-any.whl
```

**全局选项：**

| 选项 | 说明 |
|------|------|
| `--version` | 显示当前版本号 |

---

#### 3.1 `convert` - 单文件转换

将单个 SQL 文件从源端方言转换为目标 Oracle 方言。

```bash
ora-sql-change convert <INPUT_FILE> [OPTIONS]
```

**参数：**

| 参数 | 必填 | 说明 |
|------|------|------|
| `INPUT_FILE` | 是 | 输入 SQL 文件路径（必须存在） |

**选项：**

| 选项 | 默认值 | 说明 |
|------|--------|------|
| `-s, --source` | `mysql` | 源数据库类型，可选：`mysql`、`sqlserver`、`postgresql`、`db2` |
| `-t, --target` | `oracle` | 目标数据库类型（当前仅支持 `oracle`） |
| `--target-profile` | **必填** | Oracle 目标版本配置，可选：`oracle_12c`、`oracle_19c`、`oracle_26ai` |
| `-o, --output` | 输出到控制台 | 输出文件路径，指定后转换结果写入文件 |
| `-v, --verbose` | 关闭 | 显示详细信息（源文件路径、源/目标数据库、SQL 长度等） |
| `--ai` | 关闭 | 启用 AI 增强建议（需配置 API Key 或本地 LLM） |
| `--report` | 不生成 | 生成 HTML 转换报告的文件路径 |

**使用示例：**

```bash
# 基础转换：MySQL → Oracle 26ai，结果输出到控制台
ora-sql-change convert query.sql -s mysql --target-profile oracle_26ai

# 转换并保存到文件
ora-sql-change convert schema.sql -s postgresql --target-profile oracle_19c -o schema_oracle.sql

# 启用 AI 建议 + 详细输出
ora-sql-change convert complex_query.sql -s sqlserver --target-profile oracle_26ai -v --ai

# 转换并生成 HTML 报告
ora-sql-change convert report_test.sql -s db2 --target-profile oracle_12c -o result.sql --report report.html
```

**输出内容：**
- 转换后的 SQL（输出到控制台或文件）
- 语句类型标识
- 警告信息（需人工关注的转换项）
- 优化建议
- `--verbose` 时额外输出源文件路径、源/目标数据库、SQL 字符数
- `--report` 时额外生成 HTML 格式转换报告

---

#### 3.2 `batch` - 批量转换

对目录下多个 SQL 文件进行批量转换，支持并发处理。

```bash
ora-sql-change batch <INPUT_DIR> [OPTIONS]
```

**参数：**

| 参数 | 必填 | 说明 |
|------|------|------|
| `INPUT_DIR` | 是 | 输入目录路径（必须存在） |

**选项：**

| 选项 | 默认值 | 说明 |
|------|--------|------|
| `-s, --source` | `mysql` | 源数据库类型，可选：`mysql`、`sqlserver`、`postgresql`、`db2` |
| `-t, --target` | `oracle` | 目标数据库类型（当前仅支持 `oracle`） |
| `-p, --pattern` | `*.sql` | 文件匹配模式（glob 语法） |
| `-o, --output-dir` | `<INPUT_DIR>/converted` | 输出目录，不指定时在输入目录下创建 `converted` 子目录 |
| `--report` | 不生成 | 生成 HTML 批量转换报告的文件路径 |
| `--parallel` | `4` | 并发处理数 |

**使用示例：**

```bash
# 基础批量转换：将 ./sql/ 下所有 .sql 文件从 PostgreSQL 转换为 Oracle
ora-sql-change batch ./sql/ -s postgresql --target-profile oracle_26ai

# 指定输出目录 + 仅匹配特定文件
ora-sql-change batch ./input/ -s mysql --target-profile oracle_19c -p "ddl_*.sql" -o ./output/

# 8 并发 + 生成报告
ora-sql-change batch ./migration/ -s sqlserver --target-profile oracle_26ai --parallel 8 --report batch_report.html
```

**输出内容：**
- 匹配文件数量
- 每个文件的转换状态（成功/失败）
- 成功/总数统计
- 输出目录位置
- 转换后的文件命名规则：`<原文件名>_oracle.sql`
- `--report` 时额外生成包含所有文件转换详情的 HTML 报告

---

#### 3.3 `rules` - 查看转换规则

以表格形式展示指定源端数据库到 Oracle 的转换规则。

```bash
ora-sql-change rules [OPTIONS]
```

**选项：**

| 选项 | 默认值 | 说明 |
|------|--------|------|
| `-s, --source` | `mysql` | 源数据库类型，可选：`mysql`、`sqlserver`、`postgresql`、`db2` |

**使用示例：**

```bash
# 查看 MySQL → Oracle 转换规则
ora-sql-change rules -s mysql

# 查看 PostgreSQL → Oracle 转换规则
ora-sql-change rules -s postgresql

# 查看 SQL Server → Oracle 转换规则
ora-sql-change rules -s sqlserver

# 查看 Db2 → Oracle 转换规则
ora-sql-change rules -s db2
```

**输出内容：**
- 以 Rich 表格展示，包含三列：源语法、目标语法、注意事项
- 包含通用规则（如 LIMIT → FETCH FIRST、NOW()/GETDATE() → SYSDATE 等）
- 包含特定源端数据库的专有规则

---

#### 3.4 `analyze` - SQL 文件分析

对 SQL 文件进行静态分析，输出文件基本信息和转换预估。

```bash
ora-sql-change analyze <SQL_FILE> [OPTIONS]
```

**参数：**

| 参数 | 必填 | 说明 |
|------|------|------|
| `SQL_FILE` | 是 | 待分析的 SQL 文件路径（必须存在） |

**选项：**

| 选项 | 默认值 | 说明 |
|------|--------|------|
| `-s, --source` | `mysql` | 源数据库类型，可选：`mysql`、`sqlserver`、`postgresql`、`db2` |

**使用示例：**

```bash
# 分析 MySQL SQL 文件
ora-sql-change analyze complex_query.sql -s mysql

# 分析 PostgreSQL SQL 文件
ora-sql-change analyze schema.sql -s postgresql
```

**输出内容：**
- 文件行数
- SQL 对象数（CREATE TABLE / INDEX / SEQUENCE / VIEW / PROCEDURE / FUNCTION / TRIGGER 等）
- 字符数
- 语句类型（通过转换引擎的语句分类器识别）
- 预估转换时间

---

#### 3.5 `api` - 直接调用 OSC REST API

通过 CLI 直接调用 OSC REST API，复用本地持久化的服务器地址和登录会话，便于脚本化调用和自动化集成。

```bash
ora-sql-change api <COMMAND> [OPTIONS]
```

**子命令：**

| 命令 | 功能 | 需要登录 |
|------|------|----------|
| `configure` | 保存 OSC 服务器地址 | 否 |
| `login` | 登录并持久化会话 | 否 |
| `logout` | 撤销并清除本地会话 | 是 |
| `whoami` | 显示当前登录用户信息 | 是 |
| `health` | 检查 API 服务是否可达 | 否 |
| `convert` | 调用 API 转换单条 SQL | 否 |
| `analyze` | 调用 API 分析 SQL | 否 |
| `suggest` | 调用 API 生成 AI 建议 | 是 |
| `batch` | 通过 API 提交/等待/下载批量任务 | 是（未登录则本地转换） |
| `status` | 查询批量任务状态 | 是 |
| `results` | 获取批量任务结果 | 是 |
| `download` | 下载批量任务结果（ZIP/Markdown） | 是 |
| `cancel` | 取消批量任务 | 是 |
| `delete` | 删除批量任务 | 是 |

**全局配置：**

配置和会话保存在 `~/.ora-sql-change/config.json`（权限 `0600`）。

```bash
# 配置服务器地址
ora-sql-change api configure --server http://127.0.0.1:8000

# 登录（会话自动保存）
ora-sql-change api login -u admin -p <password>

# 查看当前用户
ora-sql-change api whoami
```

**转换示例：**

```bash
# 内联 SQL
ora-sql-change api convert -s db2 -q "SELECT * FROM t LIMIT 10"

# 从文件转换并保存结果
ora-sql-change api convert -s db2 -f input.sql -o output.sql

# 指定目标版本和语言
ora-sql-change api convert -s mysql -q "SELECT * FROM users LIMIT 10" --target-profile oracle_19c --language zh
```

**批量任务示例：**

```bash
# 提交单个文件并等待完成
ora-sql-change api batch -s db2 -i ./db2-sample-11.5.sql --wait

# 提交目录并下载结果
ora-sql-change api batch -s mysql -i ./sql/ --download results.zip

# 仅提交不等待
ora-sql-change api batch -s db2 -i ./db2-sample-11.5.sql

# 查询状态和结果
ora-sql-change api status <job_id>
ora-sql-change api results <job_id>

# 下载已完成任务
ora-sql-change api download <job_id> --download results.zip

# 取消或删除任务
ora-sql-change api cancel <job_id>
ora-sql-change api delete <job_id>
```

**登录态行为：**

- 已登录时，`batch` 优先走服务端 API，支持 `--wait` 轮询和 `--download` 下载
- 未登录时，`batch` 自动回退为本地转换，保证离线可用
- `suggest`、`whoami`、`status`、`results`、`download`、`cancel`、`delete` 需要登录

---

#### 3.6 AI 增强配置

使用 `--ai` 选项时，CLI 按以下优先级自动检测 AI 后端：

| 优先级 | 环境变量 | AI 后端 |
|--------|----------|---------|
| 1 | `OPENAI_API_KEY` | OpenAI |
| 2 | `ANTHROPIC_API_KEY` | Claude |
| 3 | 以上均未设置 | 本地 LLM（Ollama） |

本地 LLM 相关环境变量：

| 环境变量 | 默认值 | 说明 |
|----------|--------|------|
| `OLLAMA_ENDPOINT` | `http://localhost:11434` | Ollama 服务地址 |
| `OLLAMA_MODEL` | `codellama` | 使用的模型名称 |

### 4. AI 智能建议

- **多模型支持**：OpenAI、Claude、本地 LLM 三种后端
- **输入脱敏**：自动将字符串、邮箱、IP、数字、标识符替换为占位符后再发送至外部模型
- **结构化输出**：返回 1-2 个候选 SQL 及修复建议、性能优化建议、兼容性建议
- **速率控制**：用户级 + 全局并发双重限流
- **非权威性原则**：AI 建议始终需要人工确认

### 5. Oracle 验证

- **安全验证模式**：仅对 SELECT 语句使用 EXPLAIN PLAN 进行只读验证
- **一次性 Schema 模式**：创建随机 `OSC_TEST_XXXX` 用户，最小权限，需显式确认
- **危险操作拦截**：阻止 GRANT/REVOKE、自治事务、DBMS_SCHEDULER、UTL_/DBMS_ 包调用

### 6. 安全与权限（RBAC）

五级角色体系：

| 角色 | 权限范围 |
|------|---------|
| GUEST | 基础转换 |
| USER | 基础转换 + 基础 AI |
| POWER_USER | 高级转换 + 高级 AI + 报告 |
| ADMIN | 用户管理 + 规则管理 + 审计 |
| SUPER_ADMIN | 系统配置 + 监控 |

12 项细粒度权限：`convert:basic/advanced/batch`、`ai:basic/advanced/unlimited`、`reports:view`、`audit:view`、`users:manage`、`rules:manage`、`system:config/monitor`

通过 `X-Session-ID` 请求头管理会话，支持从密码文件（mode 0600）引导初始管理员。

### 7. 报告生成

- 支持多语言本地化：中文、英文、日文、韩文
- 输出格式：HTML / Markdown
- 内容包含：汇总统计、对象明细、源 SQL 与转换后 SQL 对照、执行结果

### 8. Web UI

基于 HTML + Tailwind CSS 的轻量级前端，提供：
- SQL 输入与转换结果展示
- 诊断信息（自动转换项 / 需人工审核项）
- 批量转换管理界面
- 报告查看

### 9. VS Code 扩展

位于 `ide/vscode/` 目录，提供编辑器内直接进行 SQL 转换的能力。

---

## 项目结构

```
ora_sql_change/
├── src/                          # 源代码
│   ├── api/                      # FastAPI 应用
│   ├── cli/                      # Click CLI
│   ├── converter/                # 转换引擎
│   │   ├── rules/                # 各源端转换规则
│   │   │   ├── mysql.py
│   │   │   ├── sqlserver.py
│   │   │   ├── postgresql.py
│   │   │   ├── db2.py
│   │   │   ├── common.py
│   │   │   └── objects.py
│   │   ├── pipeline.py           # 核心流水线
│   │   ├── models.py             # 数据模型
│   │   └── tokens.py             # TokenVault
│   ├── security/                 # RBAC 权限
│   ├── validator/                # Oracle 验证
│   ├── ai/                       # AI 集成
│   │   └── suggestions/          # 建议工作流
│   ├── storage/                  # SQLite 持久化
│   ├── report/                   # 报告生成
│   ├── i18n/                     # 国际化
│   ├── performance/              # 缓存与监控
│   ├── ui/                       # HTML 界面
│   └── resources/                # 打包文档
├── docs/                         # 项目文档
├── tests/                        # 测试用例（约 48 个文件）
├── examples/                     # 示例 SQL
├── artifacts/                    # 转换结果样例
├── ide/vscode/                   # VS Code 扩展
├── docker/                       # 源端数据库初始化脚本
├── config/                       # AI 提供商配置
├── data/                         # SQLite 数据库
├── release/                      # 分发包
├── pyproject.toml                # 构建配置
└── start.sh                      # 启动脚本
```

---

## 配置说明

| 环境变量 | 用途 |
|----------|------|
| `OSC_BOOTSTRAP_ADMIN_PASSWORD_FILE` | 管理员密码文件路径（权限 0600） |
| `OSC_BOOTSTRAP_ADMIN_USERNAME` | 管理员用户名 |
| `OSC_BOOTSTRAP_ADMIN_EMAIL` | 管理员邮箱 |
| `OSC_DATABASE_PATH` | SQLite 数据库路径 |
| `config/ai_providers.env` | AI 提供商配置 |

---

## 快速开始

### 启动 Web 服务

```bash
# 1. 创建管理员密码文件
printf '%s' 'your-password' > admin-password && chmod 600 admin-password

# 2. 设置环境变量
export OSC_BOOTSTRAP_ADMIN_PASSWORD_FILE="$PWD/admin-password"

# 3. 启动服务
./start.sh
# 访问 http://127.0.0.1:8000
```

### CLI 使用

```bash
# 安装
pip install dist/ora_sql_change-1.1.0-py3-none-any.whl

# 单文件转换
ora-sql-change convert --source mysql --input file.sql --output converted.sql

# 批量转换
ora-sql-change batch --source postgresql --input-dir ./sql/ --output-dir ./output/
```

---

## 测试

- 约 48 个 pytest 测试文件
- 样例数据库：MySQL Sakila、PostgreSQL Pagila、SQL Server AdventureWorks2022、Db2 SAMPLE
- 分发格式：wheel + sdist，附 SHA-256 校验和

---

## 设计原则

1. **诊断优先**：每次转换都输出结构化诊断信息（代码、严重级别、消息），区分自动转换与需人工审核项
2. **TokenVault 保护**：防止规则修改字面量/注释/标识符中的用户数据
3. **版本感知目标**：目标版本配置主动控制输出的 Oracle SQL 构造
4. **AI 非权威性**：AI 建议始终需人工确认，输入发送至外部模型前自动脱敏
5. **安全验证**：EXPLAIN PLAN 仅用于 SELECT；一次性 Schema 最小权限 + 显式确认
6. **单实例部署**：单 Worker、回环绑定、TLS 反向代理、内存/SQLite 状态

---

## 相关文档

- [架构设计](ARCHITECTURE.md)
- [部署指南](DEPLOYMENT.md)
- [Oracle 目标版本配置](ORACLE_TARGET_PROFILES.md)
- [转换规则详细说明](CONVERSION_RULES.md)
- [转换规则（英文简版）](CONVERSION_RULES_SIMPLE_EN.md)
- [发布检查清单](RELEASE_CHECKLIST.md)
