# Ora SQL Change Architecture

## Overview

Ora SQL Change 1.1.0 is a Python application with a shared conversion core used by FastAPI, Click CLI, batch conversion, reports, and Oracle validation.

## Conversion Core

`converter.pipeline.ConversionPipeline` protects literals and comments, applies ordered rules from `converter.rules.RuleRegistry`, invokes specialized object/procedural handlers, normalizes output, and returns diagnostics. `converter.service.Oracle26aiConversionService` remains the compatibility facade used by existing callers.

Rules are grouped by source dialect and common/object domains. Each rule declares identity, supported source database, target profiles, order, and conversion behavior. New deterministic mappings should be added as rules; unsafe semantic rewrites must emit manual-review diagnostics.

## Interfaces

- `api.main`: FastAPI Web/API application and packaged UI resources.
- `cli.main`: file, directory, and REST API invocation commands.
- `cli.api_client`: CLI-backed API client that persists server configuration and authenticated sessions.
- `api.batch`: process-local and server-side batch job execution.
- `report.generator`: localized HTML and Markdown reports.
- `validator.oracle26ai`: request-scoped Oracle connection tests and controlled validation.

## Security and State

`security.rbac` provides password hashing, roles, permissions, users, sessions, and audit metadata. Users and sessions are process-local, so deployment is limited to one worker. Rule feedback is persisted through `storage.rule_feedback.RuleFeedbackRepository` in SQLite. Reports, batch jobs, conversion cache, and execution logs are bounded or process-local runtime state.

## Target Profiles

The required profile (`oracle_12c`, `oracle_19c`, or `oracle_26ai`) controls emitted syntax and validation gates. Profile selection does not replace checking `COMPATIBLE`, character sets, NLS, time-zone files, options, privileges, and business semantics.

## Extension Flow

1. Update the reviewed rule document.
2. Add or modify a focused rule implementation.
3. Register it in the appropriate source catalog.
4. Add conversion, catalog, diagnostic, and target-profile tests.
5. Run the complete strict test suite and applicable external database tests.
