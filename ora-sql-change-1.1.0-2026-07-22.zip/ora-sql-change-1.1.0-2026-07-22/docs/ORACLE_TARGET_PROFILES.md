# Oracle Target Profiles: 12c, 19c, and 26ai

> Applies to Ora SQL Change 1.1.0 and conversion rules v1.1.0.

Ora SQL Change uses an explicit **target profile** to control Oracle compatibility mappings and pre-execution validation:

```text
oracle_12c
oracle_19c
oracle_26ai
```

A profile is not merely a label. It determines which target SQL constructs the converter may emit and which connected Oracle version may be used for validation or disposable-schema execution.

## Capability Summary

| Capability | Oracle 12c | Oracle 19c | Oracle AI Database 26ai |
|---|---|---|---|
| Primary role | Earlier enterprise baseline | Mature long-term support baseline | Current AI Database target |
| SQL `BOOLEAN` column | Not supported | Not supported | Supported |
| Native SQL `JSON` datatype | Not supported | Not supported | Supported |
| Compatible JSON storage | Character/LOB storage plus `IS JSON` constraint | Character/LOB storage plus `IS JSON` constraint | Native `JSON` preferred |
| Compatible Boolean storage | `NUMBER(1)` plus `CHECK (... IN (0, 1))` | `NUMBER(1)` plus `CHECK (... IN (0, 1))` | Native `BOOLEAN` preferred |
| Identity columns | Supported | Supported | Supported |
| `OFFSET … FETCH` | Supported | Supported | Supported |
| Baseline identifier limit used by OSC | 30 bytes | 128 bytes | 128 bytes |
| SQL `VARCHAR2` default limit | 4000 bytes; `EXTENDED` requires configuration | 4000 bytes; `EXTENDED` requires configuration | Depends on `MAX_STRING_SIZE` configuration |
| Temporary-table strategy | Global temporary table baseline | More modern options available | More modern options available |
| AI / current database capabilities | Not a target capability | Limited / environment-dependent | Primary current target |

> The actual database configuration still matters. `COMPATIBLE`, `MAX_STRING_SIZE`, character sets, NLS parameters, time-zone files, installed options, and privileges can affect whether a statement runs.

## Conversion Behavior

Consider a source table:

```sql
CREATE TABLE events (
  enabled BOOLEAN,
  payload JSON
);
```

### Oracle 12c or 19c

OSC generates a compatibility-oriented representation:

```sql
CREATE TABLE events (
  enabled NUMBER(1) CHECK (enabled IN (0, 1)),
  payload CLOB CHECK (payload IS JSON)
);
```

The mapping is syntactically compatible, but application semantics, Boolean encodings, JSON validation behavior, indexing, and storage decisions still require review.

### Oracle AI Database 26ai

OSC can retain native types:

```sql
CREATE TABLE events (
  enabled BOOLEAN,
  payload JSON
);
```

## Version Gate for Oracle Validation

The Oracle validation workflow requires the selected target profile to match the connected database before it performs safe validation or creates a disposable schema:

| Selected profile | Expected connected Oracle version |
|---|---|
| `oracle_12c` | Oracle 12.x |
| `oracle_19c` | Oracle 19.x |
| `oracle_26ai` | Explicit Oracle AI Database 26ai branding, or release version `23.26+` |

If the version does not match, OSC returns:

```text
ORACLE_VERSION_MISMATCH
```

and stops before provisioning a disposable schema or running converted SQL.

## Profile Selection Guidance

| Target environment | Select in OSC | Reason |
|---|---|---|
| Oracle Database 12c | `oracle_12c` | Avoids emitting 26ai-only SQL types and applies the 12c identifier baseline. |
| Oracle Database 19c | `oracle_19c` | Uses compatible Boolean/JSON storage instead of 26ai-only native types. |
| Oracle AI Database 26ai | `oracle_26ai` | Enables current native SQL `BOOLEAN` and `JSON` mappings. |
| Oracle version reported as `23.26.x` | `oracle_26ai` | OSC recognizes `23.26+` as an Oracle AI Database 26ai release. |

## Important Limits

A target profile addresses the **target SQL capability boundary**. It does not prove full semantic equivalence or production readiness. Review the following before deployment:

- character set and national character set compatibility;
- NLS sorting, comparison, and date/time formatting behavior;
- time-zone and daylight-saving behavior;
- `MAX_STRING_SIZE` and SQL datatype limits;
- source-to-target identity and historical-load behavior;
- JSON indexing, duplicate-key, and validation semantics;
- object dependencies, privileges, indexes, storage, and partition design;
- application driver behavior, especially for `RETURNING`, LOBs, Booleans, and JSON.

## Related Documents

- [Conversion Rules](CONVERSION_RULES.md)
- [Heterogeneous Migration Test Cases](异构数据库迁移转换工具测试用例.md)
