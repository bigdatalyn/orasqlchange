#!/bin/bash

# 从任意工作目录启动时，固定使用脚本所在的项目根目录。
PROJECT_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd "$PROJECT_ROOT" || exit 1

if [ -n "${PYTHONPATH:-}" ]; then
    export PYTHONPATH="$PROJECT_ROOT:$PROJECT_ROOT/src:$PYTHONPATH"
else
    export PYTHONPATH="$PROJECT_ROOT:$PROJECT_ROOT/src"
fi

# 安全启动参数
HOST=${OSC_HOST:-127.0.0.1}
PORT=${OSC_PORT:-${PORT:-8000}}

# 只停止确认属于 Ora SQL Change 的现有 Uvicorn 进程，避免误杀其他服务。
if ! command -v lsof >/dev/null 2>&1; then
    echo "❌ lsof is required to verify port $PORT before startup." >&2
    exit 1
fi

PIDS=$(lsof -tiTCP:"$PORT" -sTCP:LISTEN 2>/dev/null | sort -u || true)
OSC_PIDS=""
UNKNOWN_PIDS=""
for process_id in $PIDS; do
    process_command=$(ps -p "$process_id" -o command= 2>/dev/null || true)
    if [[ "$process_command" == *uvicorn* && "$process_command" == *api.main:app* ]]; then
        OSC_PIDS="$OSC_PIDS $process_id"
    else
        UNKNOWN_PIDS="$UNKNOWN_PIDS $process_id"
        echo "❌ Port $PORT is used by another process: PID $process_id ${process_command:-[command unavailable]}" >&2
    fi
done

if [ -n "$UNKNOWN_PIDS" ]; then
    exit 1
fi

if [ -n "$OSC_PIDS" ]; then
    echo "Stopping existing Ora SQL Change process on port $PORT..."
    for process_id in $OSC_PIDS; do
        kill "$process_id" 2>/dev/null || true
    done
    attempts=0
    while lsof -tiTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; do
        attempts=$((attempts + 1))
        if [ "$attempts" -ge 50 ]; then
            echo "Existing Ora SQL Change process did not stop in time; forcing shutdown."
            for process_id in $OSC_PIDS; do
                kill -9 "$process_id" 2>/dev/null || true
            done
            break
        fi
        sleep 0.1
    done
fi

REMAINING_PIDS=$(lsof -tiTCP:"$PORT" -sTCP:LISTEN 2>/dev/null | sort -u || true)
if [ -n "$REMAINING_PIDS" ]; then
    echo "❌ Port $PORT remains in use by PID(s): $REMAINING_PIDS" >&2
    exit 1
fi

if ! python3 -c 'import importlib.util, sys; sys.exit(0 if importlib.util.find_spec("api.main") else 1)'; then
    echo "❌ Ora SQL Change is not installed. Run: python3 -m pip install dist/ora_sql_change-1.1.0-py3-none-any.whl" >&2
    exit 1
fi

UVICORN_ARGS=(api.main:app --host "$HOST" --port "$PORT" --workers 1)
if [ "${OSC_RELOAD:-0}" = "1" ]; then
    UVICORN_ARGS+=(--reload)
fi

exec python3 -m uvicorn "${UVICORN_ARGS[@]}"
